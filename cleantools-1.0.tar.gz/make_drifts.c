#include <stdio.h>
#include <math.h>
#include "idl_export.h"

IDL_VPTR make_drifts(int argc, IDL_VPTR argv[]) {
/* Declare variables from IDL */